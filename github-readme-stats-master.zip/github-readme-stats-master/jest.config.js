module.exports = {
  clearMocks: true,
};
